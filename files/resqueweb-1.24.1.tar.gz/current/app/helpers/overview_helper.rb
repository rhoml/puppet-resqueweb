module OverviewHelper
  include QueuesHelper
  include WorkingHelper
end
