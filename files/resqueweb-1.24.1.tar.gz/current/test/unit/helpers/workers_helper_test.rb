require 'test_helper'

class WorkersHelperTest < ActionView::TestCase
end
