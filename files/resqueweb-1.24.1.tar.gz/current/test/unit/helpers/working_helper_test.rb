require 'test_helper'

class WorkingHelperTest < ActionView::TestCase
end
