require 'test_helper'

class FailuresHelperTest < ActionView::TestCase
end
