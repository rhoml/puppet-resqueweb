require 'test_helper'

class JobsHelperTest < ActionView::TestCase
end
