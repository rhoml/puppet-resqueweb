require 'test_helper'

class QueuesHelperTest < ActionView::TestCase
end
